﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace uLearn.Courses.BasicProgramming.Slides.U08_Recursion
{
	[Slide("BinSearch", "{8C2FB34E-7E77-481D-A192-0EA5B10B44D4}")]
	class S080_BinSearch
	{
		//#video nX2QeYilOd8
	}
}
