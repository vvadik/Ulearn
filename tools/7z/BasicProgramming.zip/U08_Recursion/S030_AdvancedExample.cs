﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace uLearn.Courses.BasicProgramming.Slides.U08_Recursion
{
	[Slide("Еще примеры", "{6F486E9A-D90F-45B3-8188-CA1F641A9753}")]
	class S030_Example
	{
		//#video vq_v5xd13WU
	}
}
