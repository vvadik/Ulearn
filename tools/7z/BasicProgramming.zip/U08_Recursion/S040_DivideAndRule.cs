﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace uLearn.Courses.BasicProgramming.Slides.U08_Recursion
{
	[Slide("Разделяй и властвуй", "{D7D3B6F8-0171-4155-B6D0-B99A3885EB37}")]
	class S040_Divide
	{
		//#video 9sfInk1wSBE
	}
}
