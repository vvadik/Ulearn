﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace uLearn.Courses.BasicProgramming.Slides.U08_Recursion
{
	[Slide("Сравнение поисков", "{7CCF616E-FF96-47C0-BEB6-861F981A4F38}")]
	class S090_Comparing
	{
		//#video 7hiaKD2mDn
	}
}
