﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace uLearn.Courses.BasicProgramming.Slides.Slides.U02_Mistakes
{
	[Slide("Выделение методов", "{32DE768E-E749-4EE2-8C0C-A75B83A62F58}")]
	class S090_MethodRefactoring
	{
		//#video 8FWm-v0e-Ro
	}
}
