﻿namespace uLearn.Courses.BasicProgramming.Slides.Slides.U02_Mistakes
{
	[Slide("Отладка", "{B591027E-9E13-4125-8A4F-7A432FBCEA7D}")]
	class S050_DebugVideo
	{
		//#video bxwvWZRG8Mk
	}
}
