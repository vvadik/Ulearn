﻿namespace uLearn.Courses.BasicProgramming.Slides.Slides.U02_Mistakes
{
	[Slide("Эксперименты", "{4EFBB2FB-151E-4BDF-ACE2-03C2A97DD410}")]
	class S060_Experiments
	{
		//#video zovN6wClw5c
	}
}
