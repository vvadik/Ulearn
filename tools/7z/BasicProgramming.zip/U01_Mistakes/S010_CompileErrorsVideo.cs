﻿namespace uLearn.Courses.BasicProgramming.Slides.Slides.U02_Mistakes
{
	[Slide("Ошибки на этапе компиляции", "{4A19ED27-B363-4F7A-A389-8388AD3ECBDF}")]
	internal class S010_CompileErrorsVideo
	{
		//#video 28v3_TnCR0A

		/*
		## Заметки по лекции
		*/

		//#include U01_Mistakes._MissedUsings.cs
	}
}
