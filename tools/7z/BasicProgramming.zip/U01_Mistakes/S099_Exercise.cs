﻿namespace uLearn.Courses.BasicProgramming.Slides
{
	[Slide("Практика", "{3AD2D195-94B7-457C-A508-AA95EB70ED37}")]
	class S099_Exercise
	{
		/*
		В дальнейшем каждый модуль будет заканчиваться слайдом с практическими задачами для самостоятельного решения.

		Студентам ИМКН УрФУ предстоит сдавать эти задачи своим преподавателям на компьютерных практиках.

		*/
		//#http https://raw.githubusercontent.com/urfu-code/cs101-01-expr/master/README.md
	}
}
