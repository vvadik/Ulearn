﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace uLearn.Courses.BasicProgramming.Slides.Slides.U02_Mistakes
{
	[Slide("Стилистические ошибки", "{1FAAA541-C3F5-4D77-9C27-D0FA634FB180}")]
	class S070_Style
	{
		//#video jFcZaDkvzYI
	}
}
