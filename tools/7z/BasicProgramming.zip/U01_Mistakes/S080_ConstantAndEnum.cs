﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace uLearn.Courses.BasicProgramming.Slides.Slides.U02_Mistakes
{
	[Slide("Константы и enum'ы", "{C235A1E3-67E7-4DCF-A06C-4298F8D52CC9}")]
	class S080_ConstantAndEnum
	{
		//#video qypMA0C1_NE
	}
}
