﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace uLearn.Courses.BasicProgramming.Slides.Slides.U02_Mistakes
{
	[Slide("Рефакторинг", "{256FC426-4AFE-4207-8778-D0F4B0D091DE}")]
	class S075_RefactoringVideo
	{
		//#video va3WnTrOHr8
	}
}
