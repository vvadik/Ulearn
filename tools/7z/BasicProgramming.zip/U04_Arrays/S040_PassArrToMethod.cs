﻿using System;
using uLearn;

namespace Slide06
{
	[Slide("Передача массива в метод", "{313711AD-91A4-43B4-898F-BC73F5BB1FAA}")]
    public class S060_PassArr
    {
		//#video UW8A9_r3XCQ
		/*
		[Иллюстрация карты памяти](/Courses/BasicProgramming/U04_Arrays/_S050_ValueRferenceType.odp)
		*/
	}
}