﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace uLearn.Courses.BasicProgramming.Slides.U07_Algorithms
{
	[Slide("Классы сложности", "{7C1C4614-3212-4B76-A8E0-7C03610FCB27}")]
	class S080_ComplexityClasses
	{
		//#video vz3YSTi2XQY

		/*
		[Материалы по лекции](/Courses/BasicProgramming/U07_Algorithms/_Materials.zip)
		*/
	}
}
