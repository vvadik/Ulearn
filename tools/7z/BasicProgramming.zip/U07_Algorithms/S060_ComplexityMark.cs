﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace uLearn.Courses.BasicProgramming.Slides.U07_Algorithms
{
	[Slide("Оценка сложности", "{F1991483-E9EC-4367-9ABF-3F773AF5F2C9}")]
	class S060_ComplexityMark
	{
		//#video qwx_pCfSyN0
		/*
		[Материалы по лекции](/Courses/BasicProgramming/U07_Algorithms/_Materials.zip)
		*/
	}
}
