﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace uLearn.Courses.BasicProgramming.Slides.U07_Algorithms
{
	[Slide("Базовые понятия", "{06DFE5F4-512B-4972-BAF5-60B45392D27F}")]
	class S020_BasicTerms
	{
		//#video TmU1e5OuRr4
		/*
		[Материалы по лекции](/Courses/BasicProgramming/U07_Algorithms/_Materials.zip)
		*/
	}
}
