﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace uLearn.Courses.BasicProgramming.Slides.U07_Algorithms
{
	[Slide("Измерение сложности", "{0820F9D6-0B3A-4A91-99B3-ABC4DA5A0521}")]
	class S030_ComplexityMeausure
	{
		//#video 78BFvmgOoNM
		/*
		[Материалы по лекции](/Courses/BasicProgramming/U07_Algorithms/_Materials.zip)
		*/
	}
}
