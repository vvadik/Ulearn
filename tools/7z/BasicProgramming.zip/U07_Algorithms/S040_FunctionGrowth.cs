﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace uLearn.Courses.BasicProgramming.Slides.U07_Algorithms
{
	[Slide("Рост функции", "{CB320AAB-0383-42A0-932A-95D7C8F76765}")]
	class S040_FunctionGrowth
	{
		//#video bfvDe2M5LVE
		/*
		[Материалы по лекции](/Courses/BasicProgramming/U07_Algorithms/_Materials.zip)
		*/
	}
}
