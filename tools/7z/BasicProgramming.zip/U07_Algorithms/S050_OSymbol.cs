﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace uLearn.Courses.BasicProgramming.Slides.U07_Algorithms
{
	[Slide("О-Символика", "{0A165BD3-2893-447A-B873-75C0BCCAC0C3}")]
	class S050_OSymbol
	{
		//#video HOoYSOdTroU
		/*
		[Материалы по лекции](/Courses/BasicProgramming/U07_Algorithms/_Materials.zip)
		*/
	}
}
