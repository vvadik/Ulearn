﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace uLearn.Courses.BasicProgramming.Slides.U07_Algorithms
{
	[Slide("Сложность алгоритма", "{2CA4334B-CCD3-4EB6-BEEF-5D84CF83E949}")]
	class S010_BasicComplexity
	{
		//#video aQWTrGM6HEg
	}
}
