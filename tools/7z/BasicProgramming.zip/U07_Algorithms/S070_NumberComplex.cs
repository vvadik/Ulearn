﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace uLearn.Courses.BasicProgramming.Slides.U07_Algorithms
{
	[Slide("Сложность алгоритмов с числами", "{0FC6D8B9-8E91-4A9B-A649-2C7E1B3A44A4}")]
	class S070_NumberComplex
	{
		//#video fy4fSRDjPTs
		/*
		[Материалы по лекции](/Courses/BasicProgramming/U07_Algorithms/_Materials.zip)
		*/
	}
}
