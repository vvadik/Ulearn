﻿namespace uLearn.Courses.BasicProgramming.Slides.U02_Ifs
{
	[Slide("Практика", "{21FF04E0-EF4F-4F24-AF59-B637A8394901}")]
	class S099_Exercise
	{
		//#http https://raw.githubusercontent.com/urfu-code/cs101-02-ifs/master/README.md
	}
}
