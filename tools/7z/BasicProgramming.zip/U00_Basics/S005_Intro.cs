﻿using uLearn;

namespace Lectures
{
	[Slide("О курсе", "{B0F478B3-436E-430B-B236-11877DD61864}")]
	class S005_Intro
	{
		//#video U1T0oGN2L10
	}
}
