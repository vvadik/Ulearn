﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace uLearn.Courses.BasicProgramming.Slides.U06_AutomaticTesting
{
	[Slide("Заключение", "{0AADE667-915B-40F3-BC49-F4622C57EA36}")]
	class S070_Conclusion
	{
		/*
		В заключение к лекции вы можете еще раз ознакомиться с кодом, над которым мы работали.
		Посмотрите его еще раз, всё ли вам в нём понятно?
		*/


		//#include U06_AutomaticTesting._UnitTest.cs

		//#include U06_AutomaticTesting._QuadricEquation.cs

		//#include U06_AutomaticTesting._Program.cs
	}
}
