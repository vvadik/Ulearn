﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace uLearn.Courses.BasicProgramming.Slides.U06_AutomaticTesting
{
	[Slide("Больше тестов!", "{A4B851C4-E1A5-4F0F-999B-6DBC4259C16A}")]
	class S040_MultiplyUnitTest
	{
		//#video 1njU3twK97w
	}
}
