﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace uLearn.Courses.BasicProgramming.Slides.U06_AutomaticTesting
{
	[Slide("Значение тестирования", "{4FDA5F2C-0FD8-4CC3-90F4-F67AF90D4C8C}")]
	class S060_ForWhatThisTests
	{
		//#video 7G-qfbesO34
	}
}
