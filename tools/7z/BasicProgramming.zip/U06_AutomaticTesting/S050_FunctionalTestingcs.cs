﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace uLearn.Courses.BasicProgramming.Slides.U06_AutomaticTesting
{
	[Slide("Функциональное тестирование", "{95B97EBE-5686-45A2-84FE-D5902351FF23}")]
	class S050_FunctionalTestingcs
	{
		//#video 1njU3twK97w
	}
}
