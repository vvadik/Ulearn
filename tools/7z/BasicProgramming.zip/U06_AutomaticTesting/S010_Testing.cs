﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace uLearn.Courses.BasicProgramming.Slides.U06_AutomaticTesting
{
	[Slide("Тестирование", "{BC932BC9-E3D5-4814-B469-B2093B61C116}")]
	class S010_Testing
	{
		//#video 3Av5u4IKSBg
	}
}
