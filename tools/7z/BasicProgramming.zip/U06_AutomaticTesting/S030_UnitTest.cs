﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace uLearn.Courses.BasicProgramming.Slides.U06_AutomaticTesting
{
	[Slide("Модульные тесты", "{ABEE38C2-B3CA-4CD6-A350-EEBF99C20F4A}")]
	class S030_UnitTest
	{
		//#video 7dZ-OlhVpQc
	}
}
