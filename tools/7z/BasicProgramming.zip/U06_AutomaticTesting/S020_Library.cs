﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace uLearn.Courses.BasicProgramming.Slides.U06_AutomaticTesting
{
	[Slide("Библиотеки", "{285EB51C-6256-439A-9389-DADF57786FEE}")]
	class S020_Library
	{
		//#video 51YW0O9De5Y
	}
}
