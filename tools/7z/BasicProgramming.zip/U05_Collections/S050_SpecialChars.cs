﻿using System;
using uLearn;

namespace Slide07
{
	//#video 8iMakRG35i4
	/*
	## Заметки по лекции
	*/
	[Slide("Специальные символы", "{DDA2B152-A939-4438-AB29-9666984F1A4E}")]
	public class S050_SpecialChars
    {
		//#include U05_Collections._SpecialCharsInclude.cs
    }
}