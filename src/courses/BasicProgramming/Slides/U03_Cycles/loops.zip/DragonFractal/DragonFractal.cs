﻿using System;
using System.Drawing; //Чтобы это пространство имен стало доступно, в проект был подключен Reference на сборку System.Drawing.dll
using System.Drawing.Imaging;
using System.IO;

namespace DragonFractal
{
	class DragonFractal
	{
		private const int Size = 800;
		private const int MarginSize = 100;
		private const string ImageFilename = "dragon.png";

		static void Main()
		{
			var image = new Bitmap(Size, Size);
			var g = Graphics.FromImage(image);
			g.FillRectangle(Brushes.Black, 0, 0, image.Width, image.Height);
			
			PaintDragon(image, 200000);
			
			image.Save(ImageFilename, ImageFormat.Png);
			Console.WriteLine("Finished.");
			Console.WriteLine("Result saved to {0}", Path.GetFullPath(ImageFilename));
		}

		/*
		Начните с точки (1, 0)
		На каждой итерации:
			Выберите случайно одно из следующих преобразований и примените его к текущей точке:
				1. Поворот на 45 градусов относительно нуля, сжатие в sqrt(2) раз.
				2. Поворот на 135 градусов относительно нуля, сжатие в sqrt(2) раз, сдвиг на 1 по оси X.
			Нарисуйте текущую точку методом SetPixel.

		Полюбуйтесь результатом в файле dragon.png
		*/
		private static void PaintDragon(Bitmap image, int iterationsCount)
		{
			//TODO
		}

		private static void SetPixel(Bitmap image, double x, double y)
		{
			var xx = Scale(x);
			var yy = Scale(y);
			if (xx >=0 && xx < image.Width && yy >= 0 && yy < image.Height)
				image.SetPixel(xx, yy, Color.Yellow);
		}

		static int Scale(double x)
		{
			return (int)Math.Round(Size / 2.0 + (Size / 2.0 - MarginSize) * x);
		}
	}
}
