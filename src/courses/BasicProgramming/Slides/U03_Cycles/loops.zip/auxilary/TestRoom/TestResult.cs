namespace TestingRoom
{
	public enum TestResult
	{
		Unknown = 0,
		OK = 1,
		Failed = 2
	}
}