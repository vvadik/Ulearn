﻿using System;

namespace Mazes
{
	public static class MazeTasks
	{
		/*
		* Не нужно писать код выхода из произвольного лабиринта. Напишите, решение для конкретных лабиринтов.
		* Используйте циклы. Ваш К.О.
		* Постарайтесь решить задачу с ограничение "не более одного цикла на метод".
		* Подумайте, какие вспомогательные методы помогут сделать ваше решение более лаконичным, понятным и красивым.
		*/
		public static void MoveOutFromEmptyMaze(Robot robot, int width, int height)
		{
		}

		public static void MoveOutFromSnakeMaze(Robot robot, int width, int height)
		{
		}

		public static void MoveOutFromPyramidMaze(Robot robot, int width, int height)
		{
		}
	}
}