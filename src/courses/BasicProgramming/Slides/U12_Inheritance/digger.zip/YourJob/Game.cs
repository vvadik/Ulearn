﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Digger
{
    public class Game
    {

        public static ICreature[,] Map;
        public static int MapWidth;
        public static int MapHeight;
        public static int Scores;
        public static bool IsOver;


        public static void CreateMap()
        {
            //TODO: Инициализируйте здесь карту
        }

    }
}
