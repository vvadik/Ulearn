﻿using System;

namespace Presentation.Slides.U99_Presentation
{
	public class FirstStep
	{
		static public void Main()
		{
			Console.WriteLine("The first step!");
		}
	}
}
