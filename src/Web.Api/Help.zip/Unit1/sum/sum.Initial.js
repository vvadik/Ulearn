//#region Task
const sum = (x, y) => 
//#endregion Task

export default sum;
