//#region Task
const sum = (x, y) => x + y;
//#endregion Task

export default sum;
