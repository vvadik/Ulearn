﻿public class Code
{
    //region main
    public static void Main(int argc, string[] argv)
    {
        System.out.println(argc);
    }
    //endregion main
}