#region main
def main():
	print("Hello, World!")
#endregion main

if __name__ == "__main__":
	main()