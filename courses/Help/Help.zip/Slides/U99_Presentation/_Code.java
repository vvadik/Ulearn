﻿public class Code
{
    //region Main
    public static void Main(int argc, string[] argv)
    {
        System.out.println(argc);
    }
    //endregion Main
}